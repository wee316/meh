package project.repository;

import project.entity.Category;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

public class JdbcCategoryRepository implements CategoryRepository {
    private final Connection conn;

    public JdbcCategoryRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Category category) {
        try {
            if (category.getId() == 0) {
                String sql = "INSERT INTO categories (name, description) VALUES (?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, category.getName());
                    stmt.setString(2, category.getDescription());
                    stmt.executeUpdate();
                    try (ResultSet rs = stmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            category.setId(rs.getInt(1)); // maps to category_id
                        }
                    }
                }
            } else {
                String sql = "UPDATE categories SET name=?, description=? WHERE category_id=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, category.getName());
                    stmt.setString(2, category.getDescription());
                    stmt.setInt(3, category.getId());
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error saving category", e);
        }
    }

    @Override
    public Category findById(int id) {
        String sql = "SELECT category_id, name, description FROM categories WHERE category_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Category(
                        rs.getInt("category_id"),
                        rs.getString("name"),
                        rs.getString("description")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching category id=" + id, e);
        }
        return null;
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM categories WHERE category_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting category id=" + id, e);
        }
    }

    @Override
    public Collection<Category> findAll() {
        Collection<Category> list = new ArrayList<>();
        String sql = "SELECT category_id, name, description FROM categories";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(new Category(
                    rs.getInt("category_id"),
                    rs.getString("name"),
                    rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error listing categories", e);
        }
        return list;
    }
}