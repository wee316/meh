package project.repository;

import project.entity.Request;
import java.util.Collection;

public interface RequestRepository {
    void save(Request request);
    Request findById(int id);
    void delete(int id);
    Collection<Request> findAll();
    Collection<Request> search(String query);
}
