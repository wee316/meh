package project.repository;

import project.entity.Report;
import java.util.Collection;

public interface ReportRepository {
    void save(Report report);
    Report findById(int id);
    void delete(int id);
    Collection<Report> findAll();
}
