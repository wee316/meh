package project.repository;

import project.entity.Report;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

public class JdbcReportRepository implements ReportRepository {
    private final Connection conn;

    public JdbcReportRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Report report) {
        try {
            if (report.getId() == 0) {
                String sql = "INSERT INTO reports (type, report_date, content) VALUES (?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, report.getType());
                    stmt.setDate(2, Date.valueOf(report.getDate()));
                    stmt.setString(3, report.getContent());
                    stmt.executeUpdate();
                    try (ResultSet rs = stmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            // If you add a setId() method to Report, update it here
                        }
                    }
                }
            } else {
                String sql = "UPDATE reports SET type=?, report_date=?, content=? WHERE report_id=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, report.getType());
                    stmt.setDate(2, Date.valueOf(report.getDate()));
                    stmt.setString(3, report.getContent());
                    stmt.setInt(4, report.getId());
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error saving report", e);
        }
    }

    @Override
    public Report findById(int id) {
        String sql = "SELECT report_id, type, report_date, content FROM reports WHERE report_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Report(
                        rs.getInt("report_id"),
                        rs.getString("type"),
                        rs.getDate("report_date").toLocalDate(),
                        rs.getString("content")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching report id=" + id, e);
        }
        return null;
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM reports WHERE report_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting report id=" + id, e);
        }
    }

    @Override
    public Collection<Report> findAll() {
        Collection<Report> list = new ArrayList<>();
        String sql = "SELECT report_id, type, report_date, content FROM reports";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(new Report(
                    rs.getInt("report_id"),
                    rs.getString("type"),
                    rs.getDate("report_date").toLocalDate(),
                    rs.getString("content")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error listing reports", e);
        }
        return list;
    }
}
