package project.repository;

import project.entity.Category;
import java.util.Collection;

public interface CategoryRepository {
    void save(Category category);
    Category findById(int id);
    void delete(int id);
    Collection<Category> findAll();
}
