package project.repository;

import project.entity.Request;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

public class JdbcRequestRepository implements RequestRepository {
    private final Connection conn;

    public JdbcRequestRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Request request) {
        try {
            if (request.getId() == 0) {
                // Insert new request
                String sql = "INSERT INTO requests (pin_id, description, views, shortlist_count) VALUES (?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, request.getPinId());
                    stmt.setString(2, request.getDescription());
                    stmt.setInt(3, request.getViews());
                    stmt.setInt(4, request.getShortlistCount());
                    stmt.executeUpdate();

                    try (ResultSet rs = stmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            request.setId(rs.getInt(1));
                        }
                    }
                }
            } else {
                // Update existing request
                String sql = "UPDATE requests SET pin_id=?, description=?, views=?, shortlist_count=? WHERE request_id=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, request.getPinId());
                    stmt.setString(2, request.getDescription());
                    stmt.setInt(3, request.getViews());
                    stmt.setInt(4, request.getShortlistCount());
                    stmt.setInt(5, request.getId());
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error saving request", e);
        }
    }

    @Override
    public Request findById(int id) {
        String sql = "SELECT request_id, pin_id, description, views, shortlist_count FROM requests WHERE request_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Request r = new Request(
                        rs.getInt("request_id"),
                        rs.getString("pin_id"),
                        rs.getString("description")
                    );
                    r.setViews(rs.getInt("views"));
                    r.setShortlistCount(rs.getInt("shortlist_count"));
                    return r;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching request id=" + id, e);
        }
        return null;
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM requests WHERE request_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting request id=" + id, e);
        }
    }

    @Override
    public Collection<Request> findAll() {
        String sql = "SELECT request_id, pin_id, description, views, shortlist_count FROM requests";
        Collection<Request> list = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Request r = new Request(
                    rs.getInt("request_id"),
                    rs.getString("pin_id"),
                    rs.getString("description")
                );
                r.setViews(rs.getInt("views"));
                r.setShortlistCount(rs.getInt("shortlist_count"));
                list.add(r);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error listing requests", e);
        }
        return list;
    }
    @Override
    public Collection<Request> search(String query) {
        String sql = "SELECT request_id, pin_id, description, views, shortlist_count FROM requests " +
                     "WHERE LOWER(description) LIKE ? OR LOWER(pin_id) LIKE ?";
        Collection<Request> results = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            String q = "%" + query.toLowerCase() + "%";
            stmt.setString(1, q);
            stmt.setString(2, q);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Request r = new Request(
                        rs.getInt("request_id"),
                        rs.getString("pin_id"),
                        rs.getString("description")
                    );
                    r.setViews(rs.getInt("views"));
                    r.setShortlistCount(rs.getInt("shortlist_count"));
                    results.add(r);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error searching requests", e);
        }
        return results;
    }
}