package project.repository;

import project.entity.Match;
import java.util.List;

public interface MatchRepository {
    void save(Match match);
    Match findById(int id);
    List<Match> findAll();
    List<Match> findByPinId(String pinId);
    List<Match> findByVolunteerId(String volunteerId);
    List<Match> search(String keyword);
    List<Match> findByRequestId(int requestId);
}