package project.repository;

import project.entity.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

public class JdbcUserRepository implements UserRepository {
    private final Connection conn;

    public JdbcUserRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(User user) {
        String sql = "INSERT INTO users (username, password_hash, role, status) " +
                     "VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), " +
                     "role = VALUES(role), status = VALUES(status)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPasswordHash());
            stmt.setString(3, user.getRole());
            stmt.setString(4, user.isActive() ? "ACTIVE" : "SUSPENDED");
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public User findByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User u = new User(
                    rs.getString("username"),
                    rs.getString("password_hash"),
                    rs.getString("role")
                );
                if (!"ACTIVE".equalsIgnoreCase(rs.getString("status"))) {
                    u.suspend();
                }
                return u;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void delete(String username) {
        String sql = "DELETE FROM users WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Collection<User> findAll() {
        Collection<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                User u = new User(
                    rs.getString("username"),
                    rs.getString("password_hash"),
                    rs.getString("role")
                );
                if (!"ACTIVE".equalsIgnoreCase(rs.getString("status"))) {
                    u.suspend();
                }
                users.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
}