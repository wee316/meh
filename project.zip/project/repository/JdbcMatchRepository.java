package project.repository;

import project.entity.Match;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class JdbcMatchRepository implements MatchRepository {
    private final Connection conn;

    public JdbcMatchRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Match match) {
        try {
            if (match.getId() == 0) {
                String sql = "INSERT INTO matches (pin_id, volunteer_id, request_id, completed_at) VALUES (?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, match.getPinId());
                    stmt.setString(2, match.getVolunteerId());
                    stmt.setInt(3, match.getRequestId());
                    stmt.setTimestamp(4, Timestamp.valueOf(match.getCompletedAt()));
                    stmt.executeUpdate();

                    try (ResultSet rs = stmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            match.setId(rs.getInt(1));
                        }
                    }
                }
            } else {
                String sql = "UPDATE matches SET pin_id=?, volunteer_id=?, request_id=?, completed_at=? WHERE match_id=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, match.getPinId());
                    stmt.setString(2, match.getVolunteerId());
                    stmt.setInt(3, match.getRequestId());
                    stmt.setTimestamp(4, Timestamp.valueOf(match.getCompletedAt()));
                    stmt.setInt(5, match.getId());
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error saving match", e);
        }
    }

    @Override
    public Match findById(int id) {
        String sql = "SELECT * FROM matches WHERE match_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding match id=" + id, e);
        }
        return null;
    }

    @Override
    public List<Match> findAll() {
        List<Match> list = new ArrayList<>();
        String sql = "SELECT * FROM matches";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error listing matches", e);
        }
        return list;
    }

    @Override
    public List<Match> findByPinId(String pinId) {
        return findByField("pin_id", pinId);
    }

    @Override
    public List<Match> findByVolunteerId(String volunteerId) {
        return findByField("volunteer_id", volunteerId);
    }

    private List<Match> findByField(String field, String value) {
        List<Match> list = new ArrayList<>();
        String sql = "SELECT * FROM matches WHERE " + field + "=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, value);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding matches by " + field, e);
        }
        return list;
    }

    private Match mapRow(ResultSet rs) throws SQLException {
        Match m = new Match(
            rs.getInt("match_id"),
            rs.getString("pin_id"),
            rs.getString("volunteer_id"),
            rs.getInt("request_id")
        );
        Timestamp ts = rs.getTimestamp("completed_at");
        if (ts != null) {
            m.setCompletedAt(ts.toLocalDateTime());
        } else {
            m.setCompletedAt(LocalDateTime.now());
        }
        return m;
    }
    @Override
    public List<Match> search(String keyword) {
        List<Match> results = new ArrayList<>();
        String sql = "SELECT * FROM matches WHERE LOWER(pin_id) LIKE ? OR LOWER(volunteer_id) LIKE ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            String q = "%" + keyword.toLowerCase() + "%";
            stmt.setString(1, q);
            stmt.setString(2, q);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    results.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error searching matches", e);
        }
        return results;
    }
    @Override
    public List<Match> findByRequestId(int requestId) {
        List<Match> list = new ArrayList<>();
        String sql = "SELECT * FROM matches WHERE request_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding matches by request ID", e);
        }
        return list;
    }
}
