package project.controller;

import project.entity.Report;
import project.repository.ReportRepository;

import java.time.LocalDate;

public class ReportController {
    private final ReportRepository repo;

    public ReportController(ReportRepository repo) {
        this.repo = repo;
    }

    public Report generateDailyReport() {
        Report r = new Report(0, "DAILY", LocalDate.now(), "Daily system usage summary...");
        repo.save(r);
        return r;
    }

    public Report generateWeeklyReport() {
        Report r = new Report(0, "WEEKLY", LocalDate.now(), "Weekly volunteer activity summary...");
        repo.save(r);
        return r;
    }

    public Report generateMonthlyReport() {
        Report r = new Report(0, "MONTHLY", LocalDate.now(), "Monthly performance overview...");
        repo.save(r);
        return r;
    }

    public Report viewReport(int id) {
        return repo.findById(id);
    }
}