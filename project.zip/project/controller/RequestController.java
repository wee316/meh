package project.controller;

import project.entity.Request;
import project.entity.Match;
import project.repository.RequestRepository;
import project.repository.MatchRepository;

import java.util.*;

public class RequestController {
    private final RequestRepository repo;
    private final MatchRepository matchRepo;
    // Keep shortlist in memory (optional: could persist later)
    private final List<Request> shortlist = new ArrayList<>();

    // Keep match history in memory (optional: could persist later)
    private final Map<String, List<Match>> matchHistoryByUser = new HashMap<>();

    public RequestController(RequestRepository repo, MatchRepository matchRepo) {
        this.repo = repo;
        this.matchRepo = matchRepo;
    }


    // ---- Methods used by CSRUI ----
    public List<Request> searchRequests(String query) {
        String q = (query == null) ? "" : query.toLowerCase();
        List<Request> results = new ArrayList<>();
        for (Request r : repo.findAll()) {
            if (r.summary().toLowerCase().contains(q)) {
                results.add(r);
            }
        }
        return results;
    }

    public void saveToShortlist(int id) {
        Request r = repo.findById(id);
        if (r != null) {
            r.incrementShortlistCount();
            repo.save(r); // persist updated shortlist count
            shortlist.add(r);
        }
    }

    public List<Request> viewShortlist() {
        return new ArrayList<>(shortlist);
    }

    public List<Match> viewCompletedMatches() {
        return Collections.emptyList(); // placeholder
    }
    public List<Request> searchShortlist(String query) {
        String q = (query == null) ? "" : query.toLowerCase();
        List<Request> results = new ArrayList<>();
        for (Request r : shortlist) {
            if (r.summary().toLowerCase().contains(q)) {
                results.add(r);
            }
        }
        return results;
    }
    public List<Match> searchMatchHistory(String query) {
        String q = (query == null) ? "" : query.toLowerCase();
        List<Match> results = new ArrayList<>();
        for (List<Match> matches : matchHistoryByUser.values()) {
            for (Match m : matches) {
                if (m.summary().toLowerCase().contains(q)) {
                    results.add(m);
                }
            }
        }
        return results;
    }

    // ---- Methods used by PINUI ----
    public Request createRequest(String pinId, String description) {
        Request r = new Request(0, pinId, description);
        repo.save(r);
        return r;
    }

    public Request viewRequest(int id) {
        Request r = repo.findById(id);
        if (r != null) {
            r.incrementViews();
            repo.save(r); // persist updated views
        }
        return r;
    }

    public Request updateRequest(int id, String newDescription) {
        Request r = repo.findById(id);
        if (r != null) {
            r.setDescription(newDescription);
            repo.save(r);
        }
        return r;
    }

    public void deleteRequest(int id) {
        repo.delete(id);
    }

    public String viewRequestStats(int id) {
        Request r = repo.findById(id);
        if (r == null) return "Request not found.";
        return "Views: " + r.getViews() + " | Shortlisted: " + r.getShortlistCount();
    }

    public List<Match> viewCompletedMatchesHistory(String username) {
        return new ArrayList<>(matchHistoryByUser.getOrDefault(username, Collections.emptyList()));
    }

    public void addCompletedMatch(String username, Match match) {
        matchHistoryByUser.computeIfAbsent(username, k -> new ArrayList<>()).add(match);
    }
    public Match completeRequest(int requestId, String volunteerId) {
        Request r = repo.findById(requestId);
        if (r == null) throw new IllegalArgumentException("Request not found.");

        Match match = new Match(
        	    0,
        	    r.getPinId(),
        	    volunteerId,
        	    r.getId()
        	);

        matchRepo.save(match); // persist to DB
        addCompletedMatch(r.getPinId(), match); // track history for PIN
        return match;
    }
    
}