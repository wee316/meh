package project.controller;

import project.entity.Match;
import project.entity.Request;
import project.repository.MatchRepository;
import project.repository.RequestRepository;

import java.util.List;

public class MatchController {
    private final MatchRepository matchRepo;
    private final RequestRepository requestRepo;

    public MatchController(MatchRepository matchRepo, RequestRepository requestRepo) {
        this.matchRepo = matchRepo;
        this.requestRepo = requestRepo;
    }

    // Complete a request by pairing it with a volunteer
    public Match completeRequest(int requestId, String volunteerId) {
        Request r = requestRepo.findById(requestId);
        if (r == null) return null;

        Match m = new Match(0, r.getPinId(), volunteerId, r.getId());
        matchRepo.save(m);
        return m;
    }

    // View all matches
    public List<Match> viewAllMatches() {
        return matchRepo.findAll();
    }

    // View matches for a specific PIN
    public List<Match> viewMatchesByPin(String pinId) {
        return matchRepo.findByPinId(pinId);
    }

    // View matches for a specific volunteer
    public List<Match> viewMatchesByVolunteer(String volunteerId) {
        return matchRepo.findByVolunteerId(volunteerId);
    }
}
