package project.controller;

import javax.swing.JFrame;
import project.entity.User;
import project.repository.UserRepository;
import project.boundary.*; // import your UI classes

public class AuthController {
    private UserRepository repo;
    private User currentUser;

    // Dependencies for UI creation
    private UserController userController;
    private ProfileController profileController;
    private RequestController requestController;
    private CategoryController categoryController;
    private ReportController reportController;

    public AuthController(UserRepository repo,
                          UserController userController,
                          ProfileController profileController,
                          RequestController requestController,
                          CategoryController categoryController,
                          ReportController reportController) {
        this.repo = repo;
        this.userController = userController;
        this.profileController = profileController;
        this.requestController = requestController;
        this.categoryController = categoryController;
        this.reportController = reportController;
    }

    public boolean authenticate(String username, String password) {
        User user = repo.findByUsername(username);
        if (user != null && user.getPasswordHash().equals(password) && user.isActive()) {
            currentUser = user;
            return true;
        }
        return false;
    }

    public void logout() {
        currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public String getCurrentUserRole() {
        return (currentUser != null) ? currentUser.getRole() : null;
    }

    // Orchestration logic moved here
    public JFrame getNextUIForRole(User user) {
    	System.out.println("Routing user: " + user.getUsername() + " with role: " + user.getRole());
    	
        return switch (user.getRole().toUpperCase()) {
        	case "ADMIN" -> new AdminUI(userController, profileController, this);
            case "CSR" -> new CSRUI(requestController, this);
            case "PIN" -> new PINUI(requestController, user.getUsername(),this);
            case "PLATFORM" -> new PlatformUI(categoryController, reportController,this);
            default -> throw new IllegalArgumentException("Unknown role: " + user.getRole());
        };
    }
}
