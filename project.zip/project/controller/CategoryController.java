package project.controller;

import project.entity.Category;
import project.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.List;

public class CategoryController {
    private final CategoryRepository repo;

    public CategoryController(CategoryRepository repo) {
        this.repo = repo;
    }

    public Category createCategory(String name, String description) {
        Category c = new Category(0, name, description);
        repo.save(c);
        return c;
    }

    public Category viewCategory(int id) {
        return repo.findById(id);
    }

    public Category updateCategory(int id, String newName, String newDescription) {
        Category c = repo.findById(id);
        if (c != null) {
            c.setName(newName);
            c.setDescription(newDescription);
            repo.save(c);
        }
        return c;
    }

    public void deleteCategory(int id) {
        repo.delete(id);
    }

    public List<Category> searchCategories(String query) {
        String q = (query == null) ? "" : query.toLowerCase();
        List<Category> results = new ArrayList<>();
        for (Category c : repo.findAll()) {
            if ((c.getName() != null && c.getName().toLowerCase().contains(q)) ||
                (c.getDescription() != null && c.getDescription().toLowerCase().contains(q))) {
                results.add(c);
            }
        }
        return results;
    }
}