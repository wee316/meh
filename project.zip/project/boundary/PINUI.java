package project.boundary;

import project.controller.RequestController;
import project.entity.Request;
import project.entity.Match;
import project.controller.AuthController;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PINUI extends JFrame {
    private RequestController requestController;
    private String username;
    private static final long serialVersionUID = 1L;
    private AuthController authController;
    public PINUI(RequestController requestController, String username, AuthController authController) {
        this.requestController = requestController;
        this.username = username;
        this.authController = authController; // now it's the real one passed in
        initUI();
    }

    private void initUI() {
        setTitle("PIN Panel - " + username);
        setSize(420, 420);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center window

        Font buttonFont = new Font("SansSerif", Font.BOLD, 14);

        JButton createBtn = new JButton("Create Request");
        JButton viewBtn = new JButton("View Request");
        JButton updateBtn = new JButton("Update Request");
        JButton deleteBtn = new JButton("Delete Request");
        JButton statsBtn = new JButton("View Request Stats");
        JButton historyBtn = new JButton("View Completed Matches");
        JButton searchBtn = new JButton("Search My Requests");
        JButton exitBtn = new JButton("Exit");

        JButton[] buttons = {createBtn, viewBtn, updateBtn, deleteBtn, statsBtn, historyBtn,searchBtn, exitBtn};
        for (JButton btn : buttons) {
            btn.setFont(buttonFont);
            btn.setFocusPainted(false);
        }

        // Tooltips
        createBtn.setToolTipText("Create a new request with a description");
        viewBtn.setToolTipText("View details of a specific request");
        updateBtn.setToolTipText("Update the description of an existing request");
        deleteBtn.setToolTipText("Delete a request by ID");
        statsBtn.setToolTipText("View analytics and stats for a request");
        historyBtn.setToolTipText("View completed matches linked to your requests");
        searchBtn.setToolTipText("Search your requests by keyword");
        searchBtn.addActionListener(e -> searchMyRequests());
        exitBtn.addActionListener(e -> {
            this.dispose();
            new LoginUI(authController).setVisible(true);
        });

        JPanel buttonPanel = new JPanel(new GridLayout(7, 1, 10, 10));
        for (JButton btn : buttons) {
            buttonPanel.add(btn);
        }

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);

        // Button actions
        createBtn.addActionListener(e -> createRequest());
        viewBtn.addActionListener(e -> viewRequest());
        updateBtn.addActionListener(e -> updateRequest());
        deleteBtn.addActionListener(e -> deleteRequest());
        statsBtn.addActionListener(e -> viewStats());
        historyBtn.addActionListener(e -> viewHistory());
        exitBtn.addActionListener(e -> dispose());
    }

    private void createRequest() {
        String desc = JOptionPane.showInputDialog(this, "Enter request description:");
        if (desc != null && !desc.isBlank()) {
            Request r = requestController.createRequest(username, desc);
            JOptionPane.showMessageDialog(this, "Created:\n" + r.summary());
        }
    }

    private void viewRequest() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter request ID:"));
            Request r = requestController.viewRequest(id);
            JOptionPane.showMessageDialog(this, r != null ? r.summary() : "Request not found.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid ID.");
        }
    }

    private void updateRequest() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter request ID:"));
            String newDesc = JOptionPane.showInputDialog(this, "New description:");
            Request r = requestController.updateRequest(id, newDesc);
            JOptionPane.showMessageDialog(this, r != null ? "Updated:\n" + r.summary() : "Request not found.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input.");
        }
    }

    private void deleteRequest() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter request ID:"));
            requestController.deleteRequest(id);
            JOptionPane.showMessageDialog(this, "Request deleted: " + id);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid ID.");
        }
    }

    private void viewStats() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter request ID:"));
            String stats = requestController.viewRequestStats(id);
            JOptionPane.showMessageDialog(this, stats);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid ID.");
        }
    }

    private void viewHistory() {
        List<Match> matches = requestController.viewCompletedMatchesHistory(username);
        if (matches.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No completed matches.");
        } else {
            StringBuilder sb = new StringBuilder("Completed Matches:\n\n");
            matches.forEach(m -> sb.append(m.summary()).append("\n"));
            JOptionPane.showMessageDialog(this, sb.toString());
        }
    }
    private void searchMyRequests() {
        String query = JOptionPane.showInputDialog(this, "Enter keyword to search your requests:");
        if (query != null && !query.isBlank()) {
            List<Request> results = requestController.searchRequests(query); // optionally filter by username
            List<Request> mine = results.stream()
                .filter(r -> r.getPinId().equals(username))
                .toList();
            if (mine.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No matching requests found.");
            } else {
                StringBuilder sb = new StringBuilder("Search Results:\n\n");
                mine.forEach(r -> sb.append(r.summary()).append("\n"));
                JOptionPane.showMessageDialog(this, sb.toString());
            }
        }
    }
}