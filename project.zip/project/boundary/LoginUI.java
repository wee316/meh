package project.boundary;

import project.controller.*;
import project.entity.User;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class LoginUI extends JFrame {
    private AuthController authController;
    private static final long serialVersionUID = 1L;

    public LoginUI(AuthController authController) {
        this.authController = authController;
        initUI();
    }

    private void initUI() {
        setTitle("Volunteer Ting");
        setSize(350, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center window

        // Fonts
        Font labelFont = new Font("SansSerif", Font.PLAIN, 14);
        Font fieldFont = new Font("SansSerif", Font.PLAIN, 14);
        Font buttonFont = new Font("SansSerif", Font.BOLD, 14);

        // Fields
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JButton exitButton = new JButton("Exit");

        usernameField.setFont(fieldFont);
        passwordField.setFont(fieldFont);
        loginButton.setFont(buttonFont);
        exitButton.setFont(buttonFont);

        usernameField.setToolTipText("Enter your username");
        passwordField.setToolTipText("Enter your password");
        loginButton.setMnemonic(KeyEvent.VK_ENTER); // Alt+Enter shortcut

        // Layout
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(labelFont);
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(labelFont);

        formPanel.add(userLabel);
        formPanel.add(usernameField);
        formPanel.add(passLabel);
        formPanel.add(passwordField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(loginButton);
        buttonPanel.add(exitButton);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);

        // Actions
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (authController.authenticate(username, password)) {
                User current = authController.getCurrentUser();
                JOptionPane.showMessageDialog(this, "Welcome " + current.getRole());

                JFrame nextUI = authController.getNextUIForRole(current);
                nextUI.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid login", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        exitButton.addActionListener(e -> {
            System.exit(0); // only here do we quit the app
        });
    }
}