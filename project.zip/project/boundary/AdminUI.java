package project.boundary;

import project.controller.UserController;
import project.controller.ProfileController;
import project.controller.AuthController;
import project.entity.User;
import project.entity.Profile;

import javax.swing.*;
import java.awt.*;

public class AdminUI extends JFrame {
    private UserController userController;
    private ProfileController profileController;
    private static final long serialVersionUID = 1L;
    private AuthController authController;

    public AdminUI(UserController userController, ProfileController profileController) {
        this.userController = userController;
        this.profileController = profileController;
        initUI();
    }
    public AdminUI(UserController userController, ProfileController profileController, AuthController authController) {
        this.userController = userController;
        this.profileController = profileController;
        this.authController = authController;
        initUI();
    }

    private void initUI() {
        setTitle("Admin Panel");
        setSize(420, 320);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center window
        if (authController == null) {
            throw new IllegalStateException("AuthController must not be null in AdminUI");
        }
        Font buttonFont = new Font("SansSerif", Font.BOLD, 14);

        JButton createUserBtn = new JButton("Create User");
        JButton viewAllBtn = new JButton("View All Users");
        JButton suspendBtn = new JButton("Suspend User");
        JButton unsuspendBtn = new JButton("Unsuspend User");
        JButton updateBtn = new JButton("Update User");
        JButton searchBtn = new JButton("Search User");
        JButton searchProfileBtn = new JButton("Search Profile");
        JButton suspendProfileBtn = new JButton("Suspend Profile");
        JButton unsuspendProfileBtn = new JButton("Unsuspend Profile");
        JButton deleteBtn = new JButton("Delete User + Profile");
        JButton exitBtn = new JButton("Exit");

        JButton[] buttons = {createUserBtn, viewAllBtn, suspendBtn, unsuspendBtn, deleteBtn,updateBtn,searchBtn,searchProfileBtn,suspendProfileBtn, unsuspendProfileBtn, exitBtn};
        for (JButton btn : buttons) {
            btn.setFont(buttonFont);
            btn.setFocusPainted(false);
        }

        // Tooltips
        createUserBtn.setToolTipText("Create a new user and profile");
        viewAllBtn.setToolTipText("View all registered users");
        suspendBtn.setToolTipText("Suspend a user account");
        unsuspendBtn.setToolTipText("Reactivate a suspended user");
        deleteBtn.setToolTipText("Delete both user and profile");
        exitBtn.setToolTipText("Close the admin panel and goes back to the login page");

        JPanel buttonPanel = new JPanel(new GridLayout(6, 1, 10, 10));
        for (JButton btn : buttons) {
            buttonPanel.add(btn);
        }

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);

        // Action listeners
        createUserBtn.addActionListener(e -> createUserDialog());
        viewAllBtn.addActionListener(e -> showAllUsers());

        suspendBtn.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter username to suspend:");
            if (username != null && !username.isBlank()) {
                userController.suspendUser(username);
                JOptionPane.showMessageDialog(this, "User suspended.");
            }
        });

        unsuspendBtn.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter username to unsuspend:");
            if (username != null && !username.isBlank()) {
                userController.unsuspendUser(username);
                JOptionPane.showMessageDialog(this, "User unsuspended.");
            }
        });

        deleteBtn.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter username to delete:");
            if (username != null && !username.isBlank()) {
                userController.deleteUser(username);
                profileController.deleteProfile(username);
                JOptionPane.showMessageDialog(this, "User and profile deleted.");
            }
        });
        updateBtn.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter username to update:");
            if (username != null && !username.isBlank()) {
                User u = userController.viewUser(username);
                if (u != null) {
                    JTextField roleField = new JTextField(u.getRole());
                    JTextField passwordField = new JTextField(u.getPasswordHash());

                    Object[] fields = {
                        "Role:", roleField,
                        "Password:", passwordField
                    };

                    int option = JOptionPane.showConfirmDialog(this, fields, "Update User", JOptionPane.OK_CANCEL_OPTION);
                    if (option == JOptionPane.OK_OPTION) {
                        u.setRole(roleField.getText());
                        u.setPasswordHash(passwordField.getText());
                        userController.updateUser(u);
                        JOptionPane.showMessageDialog(this, "User updated.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "User not found.");
                }
            }
        });

        searchBtn.addActionListener(e -> {
            String query = JOptionPane.showInputDialog(this, "Enter username to search:");
            if (query != null && !query.isBlank()) {
                User u = userController.searchUser(query);
                if (u != null) {
                    JOptionPane.showMessageDialog(this, "Found: " + u.getUsername() + " | Role: " + u.getRole());
                } else {
                    JOptionPane.showMessageDialog(this, "No user found.");
                }
            }
        });

        searchProfileBtn.addActionListener(e -> {
            String query = JOptionPane.showInputDialog(this, "Enter username to search profile:");
            if (query != null && !query.isBlank()) {
                Profile p = profileController.searchProfile(query);
                if (p != null) {
                    JOptionPane.showMessageDialog(this, "Profile: " + p.getFullName() + " | Email: " + p.getEmail());
                } else {
                    JOptionPane.showMessageDialog(this, "No profile found.");
                }
            }
        });

        suspendProfileBtn.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter username to suspend profile:");
            if (username != null && !username.isBlank()) {
                profileController.suspendProfile(username);
                JOptionPane.showMessageDialog(this, "Profile suspended.");
            }
        });

        unsuspendProfileBtn.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter username to unsuspend profile:");
            if (username != null && !username.isBlank()) {
                profileController.unsuspendProfile(username);
                JOptionPane.showMessageDialog(this, "Profile unsuspended.");
            }
        });

        exitBtn.addActionListener(e -> {
            this.dispose();
            new LoginUI(authController).setVisible(true);
        });
    }

    private void createUserDialog() {
        JTextField usernameField = new JTextField();
        JTextField passwordField = new JTextField();
        JTextField roleField = new JTextField();
        JTextField fullNameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();

        Object[] fields = {
            "Username:", usernameField,
            "Password:", passwordField,
            "Role:", roleField,
            "Full Name:", fullNameField,
            "Email:", emailField,
            "Phone:", phoneField
        };

        int option = JOptionPane.showConfirmDialog(
                this, fields, "Create User + Profile", JOptionPane.OK_CANCEL_OPTION
        );
        if (option == JOptionPane.OK_OPTION) {
            User user = new User(
                    usernameField.getText(),
                    passwordField.getText(),
                    roleField.getText()
            );
            userController.createUser(user);

            Profile profile = new Profile(
                    usernameField.getText(),
                    fullNameField.getText(),
                    emailField.getText(),
                    phoneField.getText()
            );
            profileController.createProfile(profile);

            JOptionPane.showMessageDialog(this, "User and Profile created!");
        }
    }

    private void showAllUsers() {
        var users = userController.getAllUsers();
        if (users.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No users found.");
        } else {
            StringBuilder sb = new StringBuilder("--- All Users ---\n\n");
            for (User u : users) {
                sb.append("User: ").append(u.getUsername())
                  .append(" | Role: ").append(u.getRole())
                  .append(" | Active: ").append(u.isActive())
                  .append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.toString());
        }
    }
}