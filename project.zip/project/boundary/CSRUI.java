package project.boundary;

import project.controller.RequestController;
import project.entity.Request;
import project.entity.Match;
import project.controller.AuthController;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.List;

public class CSRUI extends JFrame {
    private RequestController requestController;
    private static final long serialVersionUID = 1L;
    private AuthController authController;
    public CSRUI(RequestController requestController, AuthController authController) {
        this.requestController = requestController;
        this.authController = authController;
        initUI();
    }

    private void initUI() {
        setTitle("CSR Panel");
        setSize(400, 320);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center window

        @SuppressWarnings("unused")
		Font buttonFont = new Font("SansSerif", Font.BOLD, 14);

        JButton searchBtn = new JButton("Search Requests");
        JButton shortlistBtn = new JButton("Save to Shortlist");
        JButton viewShortlistBtn = new JButton("View Shortlist");
        JButton viewMatchesBtn = new JButton("View Completed Matches");
        JButton matchBtn = new JButton("Match Request");
        JButton searchShortlistBtn = new JButton("Search Shortlist");
        JButton searchMatchHistoryBtn = new JButton("Search Match History");
        JButton exitBtn = new JButton("Exit");
        
        JButton[] buttons = {
        	    searchBtn, shortlistBtn, viewShortlistBtn, searchShortlistBtn,
        	    matchBtn, viewMatchesBtn, searchMatchHistoryBtn, exitBtn
        	};


        // Tooltips
        searchBtn.setToolTipText("Search for volunteer requests by keyword");
        shortlistBtn.setToolTipText("Enter a request ID to save to shortlist");
        viewShortlistBtn.setToolTipText("View all requests you've shortlisted");
        viewMatchesBtn.setToolTipText("View completed matches between requests and volunteers");
        matchBtn.setToolTipText("Assign a volunteer to a request to complete it");
        exitBtn.setToolTipText("Close this panel");

        // Mnemonics
        searchBtn.setMnemonic(KeyEvent.VK_S);
        shortlistBtn.setMnemonic(KeyEvent.VK_P);
        viewShortlistBtn.setMnemonic(KeyEvent.VK_V);
        viewMatchesBtn.setMnemonic(KeyEvent.VK_C);
        exitBtn.setMnemonic(KeyEvent.VK_E);

        JPanel buttonPanel = new JPanel(new GridLayout(0, 1, 10, 10));
        for (JButton btn : buttons) {
            buttonPanel.add(btn);
        }

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);

        // Button actions
        searchBtn.addActionListener(e -> searchRequests());
        shortlistBtn.addActionListener(e -> saveToShortlist());
        viewShortlistBtn.addActionListener(e -> viewShortlist());
        viewMatchesBtn.addActionListener(e -> viewCompletedMatches());
        matchBtn.addActionListener(e -> matchRequest());
        searchShortlistBtn.addActionListener(e -> searchShortlist());
        searchMatchHistoryBtn.addActionListener(e -> searchMatchHistory());


        exitBtn.addActionListener(e -> {
            this.dispose();
            new LoginUI(authController).setVisible(true);
        });
    }

    private void searchRequests() {
        String query = JOptionPane.showInputDialog(this, "Enter search query:");
        if (query != null && !query.isBlank()) {
            List<Request> results = requestController.searchRequests(query);
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No requests found.");
            } else {
                StringBuilder sb = new StringBuilder("Search Results:\n\n");
                results.forEach(r -> sb.append(r.summary()).append("\n"));
                JOptionPane.showMessageDialog(this, sb.toString());
            }
        }
    }

    private void saveToShortlist() {
        String input = JOptionPane.showInputDialog(this, "Enter request ID to shortlist:");
        if (input != null && !input.isBlank()) {
            try {
                int id = Integer.parseInt(input);
                requestController.saveToShortlist(id);
                JOptionPane.showMessageDialog(this, "Request " + id + " saved to shortlist.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid ID.");
            }
        }
    }

    private void viewShortlist() {
        List<Request> shortlist = requestController.viewShortlist();
        if (shortlist.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Shortlist is empty.");
        } else {
            StringBuilder sb = new StringBuilder("Shortlist:\n\n");
            shortlist.forEach(r -> sb.append(r.summary()).append("\n"));
            JOptionPane.showMessageDialog(this, sb.toString());
        }
    }

    private void viewCompletedMatches() {
        List<Match> matches = requestController.viewCompletedMatches();
        if (matches.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No completed matches.");
        } else {
            StringBuilder sb = new StringBuilder("Completed Matches:\n\n");
            matches.forEach(m -> sb.append(m.summary()).append("\n"));
            JOptionPane.showMessageDialog(this, sb.toString());
        }
    }
    private void matchRequest() {
        try {
            String reqInput = JOptionPane.showInputDialog(this, "Enter request ID to match:");
            String volInput = JOptionPane.showInputDialog(this, "Enter volunteer ID:");

            if (reqInput != null && volInput != null && !reqInput.isBlank() && !volInput.isBlank()) {
                int requestId = Integer.parseInt(reqInput);
                Match m = requestController.completeRequest(requestId, volInput);
                JOptionPane.showMessageDialog(this, "Match created:\n" + m.summary());
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid request ID.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error creating match: " + ex.getMessage());
        }
    }
    private void searchShortlist() {
        String query = JOptionPane.showInputDialog(this, "Enter keyword to search shortlist:");
        if (query != null && !query.isBlank()) {
            List<Request> results = requestController.searchShortlist(query);
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No matching requests in shortlist.");
            } else {
                StringBuilder sb = new StringBuilder("Shortlist Search Results:\n\n");
                results.forEach(r -> sb.append(r.summary()).append("\n"));
                JOptionPane.showMessageDialog(this, sb.toString());
            }
        }
    }

    private void searchMatchHistory() {
        String query = JOptionPane.showInputDialog(this, "Enter keyword to search match history:");
        if (query != null && !query.isBlank()) {
            List<Match> results = requestController.searchMatchHistory(query);
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No matches found.");
            } else {
                StringBuilder sb = new StringBuilder("Match History Results:\n\n");
                results.forEach(m -> sb.append(m.summary()).append("\n"));
                JOptionPane.showMessageDialog(this, sb.toString());
            }
        }
    }
}