package project.boundary;

import project.controller.CategoryController;
import project.controller.ReportController;
import project.entity.Category;
import project.entity.Report;
import project.controller.AuthController;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PlatformUI extends JFrame {
    private CategoryController categoryController;
    private ReportController reportController;
    private static final long serialVersionUID = 1L;
    private AuthController authController;
    public PlatformUI(CategoryController categoryController,
            ReportController reportController,
            AuthController authController) {
this.categoryController = categoryController;
this.reportController = reportController;
this.authController = authController; // now it's the real one passed in
initUI();
}

    private void initUI() {
        setTitle("Platform Management Panel");
        setSize(420, 460);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center window

        Font buttonFont = new Font("SansSerif", Font.BOLD, 14);

        JButton createBtn = new JButton("Create Category");
        JButton viewBtn = new JButton("View Category");
        JButton updateBtn = new JButton("Update Category");
        JButton deleteBtn = new JButton("Delete Category");
        JButton searchBtn = new JButton("Search Categories");
        JButton dailyBtn = new JButton("Daily Report");
        JButton weeklyBtn = new JButton("Weekly Report");
        JButton monthlyBtn = new JButton("Monthly Report");
        JButton exitBtn = new JButton("Exit");

        JButton[] buttons = {
            createBtn, viewBtn, updateBtn, deleteBtn,
            searchBtn, dailyBtn, weeklyBtn, monthlyBtn, exitBtn
        };

        for (JButton btn : buttons) {
            btn.setFont(buttonFont);
            btn.setFocusPainted(false);
        }

        // Tooltips
        createBtn.setToolTipText("Create a new category with name and description");
        viewBtn.setToolTipText("View details of a category by ID");
        updateBtn.setToolTipText("Update name and description of a category");
        deleteBtn.setToolTipText("Delete a category by ID");
        searchBtn.setToolTipText("Search categories by keyword");
        dailyBtn.setToolTipText("Generate today's request report");
        weeklyBtn.setToolTipText("Generate weekly request report");
        monthlyBtn.setToolTipText("Generate monthly request report");
        exitBtn.setToolTipText("Close this panel");

        JPanel buttonPanel = new JPanel(new GridLayout(9, 1, 10, 10));
        for (JButton btn : buttons) {
            buttonPanel.add(btn);
        }

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);

        // Button actions
        createBtn.addActionListener(e -> createCategory());
        viewBtn.addActionListener(e -> viewCategory());
        updateBtn.addActionListener(e -> updateCategory());
        deleteBtn.addActionListener(e -> deleteCategory());
        searchBtn.addActionListener(e -> searchCategories());

        dailyBtn.addActionListener(e -> {
            Report r = reportController.generateDailyReport();
            JOptionPane.showMessageDialog(this, r.summary());
        });

        weeklyBtn.addActionListener(e -> {
            Report r = reportController.generateWeeklyReport();
            JOptionPane.showMessageDialog(this, r.summary());
        });

        monthlyBtn.addActionListener(e -> {
            Report r = reportController.generateMonthlyReport();
            JOptionPane.showMessageDialog(this, r.summary());
        });

        exitBtn.addActionListener(e -> {
            this.dispose();
            new LoginUI(authController).setVisible(true);
        });
    }

    private void createCategory() {
        String name = JOptionPane.showInputDialog(this, "Category name:");
        String desc = JOptionPane.showInputDialog(this, "Description:");
        if (name != null && desc != null && !name.isBlank() && !desc.isBlank()) {
            Category c = categoryController.createCategory(name, desc);
            JOptionPane.showMessageDialog(this, "Category created:\n" + c.summary());
        }
    }

    private void viewCategory() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter category ID:"));
            Category c = categoryController.viewCategory(id);
            JOptionPane.showMessageDialog(this, c != null ? c.summary() : "Category not found.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid ID.");
        }
    }

    private void updateCategory() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter category ID:"));
            String newName = JOptionPane.showInputDialog(this, "New name:");
            String newDesc = JOptionPane.showInputDialog(this, "New description:");
            Category c = categoryController.updateCategory(id, newName, newDesc);
            JOptionPane.showMessageDialog(this, c != null ? "Updated:\n" + c.summary() : "Category not found.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input.");
        }
    }

    private void deleteCategory() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter category ID:"));
            categoryController.deleteCategory(id);
            JOptionPane.showMessageDialog(this, "Category deleted: " + id);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid ID.");
        }
    }

    private void searchCategories() {
        String query = JOptionPane.showInputDialog(this, "Search query:");
        if (query != null && !query.isBlank()) {
            List<Category> results = categoryController.searchCategories(query);
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No categories found.");
            } else {
                StringBuilder sb = new StringBuilder("Search Results:\n\n");
                results.forEach(c -> sb.append(c.summary()).append("\n"));
                JOptionPane.showMessageDialog(this, sb.toString());
            }
        }
    }
}