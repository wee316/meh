package project;

import java.sql.Connection;
import project.controller.*;
import project.boundary.*;
import project.repository.*;

public class Main {
    public static void main(String[] args) {
        try {
            // Get a single DB connection
            Connection conn = DBUtil.getConnection();

         // Instantiate repositories
            UserRepository userRepo = new JdbcUserRepository(conn);
            ProfileRepository profileRepo = new JdbcProfileRepository(conn);
            RequestRepository requestRepo = new JdbcRequestRepository(conn);
            CategoryRepository categoryRepo = new JdbcCategoryRepository(conn);
            ReportRepository reportRepo = new JdbcReportRepository(conn);
            MatchRepository matchRepo = new JdbcMatchRepository(conn);

            // Instantiate controllers
            UserController userController = new UserController(userRepo);
            ProfileController profileController = new ProfileController(profileRepo);
            RequestController requestController = new RequestController(requestRepo, matchRepo);
            CategoryController categoryController = new CategoryController(categoryRepo);
            ReportController reportController = new ReportController(reportRepo);

            // AuthController now takes all dependencies it needs
            AuthController authController = new AuthController(
                userRepo,
                userController,
                profileController,
                requestController,
                categoryController,
                reportController
            );

            // Launch login GUI — now only needs AuthController
            new LoginUI(authController);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
