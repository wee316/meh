package project.entity;

public class Profile {
    private String username;
    private String fullName;
    private String email;
    private String phone;
    private boolean active; // NEW: track profile status

    public Profile(String username, String fullName, String email, String phone, boolean active) {
        this.username = username;
        this.fullName = fullName;
        setEmail(email);
        this.phone = phone;
        this.active = active;
    }
    public Profile(String username, String fullName, String email, String phone) {
        this(username, fullName, email, phone, true); // delegate to the 5‑arg constructor
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) {
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email");
        }
        this.email = email;
    }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public boolean isActive() { return active; }

    // NEW: suspend/activate methods
    public void suspend() { this.active = false; }
    public void activate() { this.active = true; }

    public void updateContactInfo(String email, String phone) {
        setEmail(email);
        this.phone = phone;
    }

    public String summary() {
        return fullName + " (" + email + ", " + phone + ") | Active: " + active;
    }
}